﻿
(function Component (id) {// @lock

// Add the code that needs to be shared between components here

function constructor (id) {
	var DTlistContainer = getHtmlId('DTlistContainer'),
		DTdetailContainer = getHtmlId('DTdetailContainer'),
		DTdataGridDomId = getHtmlId('DTdataGrid2'),
		dialogDupliDomId = getHtmlId('dialogDupli'),
		buttonDupliDomId = getHtmlId('buttonDupli'),
		buttonFindDomID = getHtmlId('buttonFind'),
		buttonPrintDomID = getHtmlId('buttonPrint'),
		buttonPrevDomId = getHtmlId('buttonPrev'),
		buttonNextDomID = getHtmlId('buttonNext'),
		textFieldDateInputRef = getHtmlId('textFieldDateInput'),
		textFieldHeuresRef = getHtmlId('textFieldHeures'),

		comboboxDPI$ = getHtmlObj('comboboxDPI'); //! getHtmlObj !

	// @region beginComponentDeclaration// @startlock
	var $comp = this;
	this.name = 'detailTemps';
	// @endregion// @endlock

	this.load = function (data) {// @lock

	// @region namespaceDeclaration// @startlock
	var buttonCancel = {};	// @button
	var buttonSave = {};	// @button
	var buttonPrev = {};	// @button
	var buttonNext = {};	// @button
	var textFieldInputTemps = {};	// @textField
	var comboboxDPI = {};	// @combobox
	var buttonDelete = {};	// @button
	var DTdataGrid2 = {};	// @dataGrid
	var buttonAdd = {};	// @button
	var comboboxDay = {};	// @combobox
	var buttonDupli = {};	// @button
	var buttonDupliCancel = {};	// @button
	var buttonDupliOK = {};	// @button
	var dtDateInputVarEvent = {};	// @dataSource
	var comboWeeksArrEvent = {};	// @dataSource
	var dtDate_varEvent = {};	// @dataSource
	var detail_TempsEvent = {};	// @dataSource
	// @endregion// @endlock

	Date.prototype.addDays = function(days) {
	this.setDate(this.getDate()+days);
	};

	function addDays (date, days) {
	    var result = new Date(date);
	    result.setDate(date.getDate() + days);
	    return result;
	};

	function jsDateStr2Date (jsDateStr) {
		var	yearStr = jsDateStr.substr(0, 4),
			monthStr = String(Number(jsDateStr.substr(5, 2)) - 1), //js month 0-11
			dayStr = jsDateStr.substr(8, 2);			
		return new Date(yearStr, monthStr, dayStr);	
	};
	
	function formatDateOnly (dateObject) {
		var currDate = dateObject.getDate();
		var currMonth = dateObject.getMonth();
		currMonth++; // convert month 0-11 in 1-12 
		var currYear = dateObject.getFullYear();
		return currYear + '-' + (currMonth < 10 ? '0' : '') + currMonth + '-' + (currDate < 10 ? '0' : '') + currDate;
	};

	function firstDateOfWeek (dateObject) {
		var currDay = dateObject.getDay() || 7; // Get current day number, converting Sun. to 7
		return new Date(dateObject.getTime() - 60*60*24* currDay*1000); //will return the date of the firstday (ie sunday) of the week
	};

	function comboWeeksFill (dateObject, numberOfWeeks) {
		var currDate = dateObject.getDate(),
			currMonth = dateObject.getMonth(),
			currYear = dateObject.getFullYear();
		waf.ds.Semaine.getWeeks(currDate, currMonth, currYear, 21, {
			onSuccess: function(event) {
				$comp.sourcesVar.comboWeeksArr = event.result.slice(0);
				$comp.sources.comboWeeksArr.sync();	
				$comp.sources.comboWeeksArr.select(10);
			} //end - onSuccess
		});	
	};
	
	function timeStr2float (timeStr) {
		var timeFloat = 0,
			integerPart = 0,
			decimalPart = 0;

//		debugger;

		timeStr = timeStr.replace(/[^0-9.,-hH]/, ""); //enlever les éventuels caractères invalides
		//timeStr = timeStr.replace(/1*?[^0-9-]/, ""); //enlever les éventuels [.,hH] du début (ne marche pas)
		
		if (timeStr.indexOf("h") >= 0) {
			timeStr = timeStr.replace("h", ".");
		} else if (timeStr.indexOf("H") >= 0) {
			timeStr = timeStr.replace("H", ".");
		} else if (timeStr.indexOf(",") >= 0) {
			timeStr = timeStr.replace(",", ".");
		}

		timeFloat = parseFloat(timeStr);

		integerPart = Math.floor(timeFloat),
		decimalPart = ((timeFloat % 1).toFixed(2)) / 0.6; //convertion de minutes en centièmes d'heures			
	
		timeFloat = integerPart + decimalPart;
		return timeFloat;
	}
	
	function timeFloat2Str (timeFloat) {		
		var timeStr = "",
			integerPart = Math.floor(timeFloat),
			decimalPart = ((timeFloat % 1).toFixed(2)) * 1;
						
		timeStr = integerPart + 'h';
		
		if (decimalPart !== 0) {
			decimalPart = Math.round(decimalPart * 60); //convertion de centièmes d'heures en minutes
			timeStr += decimalPart; 
		}
		return timeStr;
	};

	function refreshTotalHeures () {
		$comp.sources.detail_Temps.getTotalTime ({
			onSuccess: function(ev){
				var resultTotal = ev.result;
				$comp.sourcesVar.totalHeures = timeFloat2Str (resultTotal);
				$comp.sources.totalHeures.sync();
				return resultTotal;
			},
			onError: function(ev){
				WAF.ErrorManager.displayError(ev);
				return 0;
			}
		});
	};
	
	function DTselectByDate (firstDate, lastDate) {
		if ((firstDate !== undefined) && (lastDate !== undefined)) {
			$comp.sources.detail_Temps.query("DET_Date <= :1 AND DET_Date >= :2 order by DET_Date, DPI_ID", firstDate, lastDate);
		} else if (firstDate !== undefined) {
			$comp.sources.detail_Temps.query("DET_Date == :1 order by DET_Date, DPI_ID", firstDate);		
		};

		refreshTotalHeures();
	};

	function comboDayFill () {
		$comp.sourcesVar.comboDayArr = [];
		$comp.sourcesVar.comboDayArr.push({dayName: 'Tous', dayNum: 0});
		$comp.sourcesVar.comboDayArr.push({dayName: 'Lundi', dayNum: 1});
		$comp.sourcesVar.comboDayArr.push({dayName: 'Mardi', dayNum: 2});
		$comp.sourcesVar.comboDayArr.push({dayName: 'Mercredi', dayNum: 3});
		$comp.sourcesVar.comboDayArr.push({dayName: 'Jeudi', dayNum: 4});
		$comp.sourcesVar.comboDayArr.push({dayName: 'Vendredi', dayNum: 5});
		$comp.sourcesVar.comboDayArr.push({dayName: 'Samedi', dayNum: 6});
		$comp.sourcesVar.comboDayArr.push({dayName: 'Dimanche', dayNum: 7});
		
		$comp.sources.comboDayArr.sync();
		$comp.sources.comboDayArr.select(0); //tous les jours de la semaine		
	};
	
	function comboDPIinit (dpiId) {
		//pour chargement comboBoxDPI
		$comp.sources.dosPosInt_A.all();
	};

	function comboDPIload (dpiId) {
		if ($comp.sources.detail_Temps.isNewElement()) {
			comboboxDPI$.find('input').val('');	
		} else {
			$comp.sources.dosPosInt_A1.query("DPI_ID = :1", dpiId, {
				onSuccess: function(event) {
					var socDosPosLib = $comp.sources.dosPosInt_A1.SocDosPos_Lib;
					//super Hack to simul selected comboBoxDPI value
					comboboxDPI$.find('input').val(socDosPosLib);	
				}
			});
		}
	};
	
	function resetPrevNextButtons() {
		if ($comp.sources.detail_Temps.isNewElement()) {
			//mask next/previous button if new entity
			$$(buttonPrevDomId).disable();
			$$(buttonNextDomID).disable();
		} else {

			//next button
			if ($comp.sources.detail_Temps.getPosition() === $comp.sources.detail_Temps.length - 1) {
				$$(buttonNextDomID).disable();
			} else {
				$$(buttonNextDomID).enable();
			}
			//previous button
			if ($comp.sources.detail_Temps.getPosition() === 0) {
				$$(buttonPrevDomId).disable();
			} else {
				$$(buttonPrevDomId).enable();
			}
		}
	}
	
	function DTinit () {
	//	$comp.sources.dtDate_var = new Date(); //Date courante
		$comp.sourcesVar.dtDate_var = new Date(2012, 6, 1); //pour tests
		$comp.sources.dtDate_var.sync();	//mise à jour interface

		$comp.sourcesVar.dtDateInputVar = new Date($comp.sourcesVar.dtDate_var);
		$comp.sources.dtDateInputVar.sync();	//mise à jour interface

		//chargement comboBox jours de la semaine
		comboDayFill ();

		//chargement comboBox semaines centrées sur la date choisie
		comboWeeksFill ($comp.sourcesVar.dtDate_var, 21);

		//chargement comboBoxDPI
		comboDPIinit ();
	
	};
	
	function DTlistLoad () {

		var selDayNum = $comp.sources.comboDayArr.getKey();
		if (selDayNum == 0) {  //tous les jours de la semaine
			//sélection détail temps de la semaine sélectionnée
			DTselectByDate ($comp.sources.comboWeeksArr.SE_Date_Fin,  $comp.sources.comboWeeksArr.SE_Date_Debut);	
		} else if ((selDayNum >= 1) && (selDayNum <=7)) {
			selDayNum--;
			//sélection détail temps du jour sélectionné de la semaine sélectionnée
			DTselectByDate (addDays (new Date($comp.sources.comboWeeksArr.SE_Date_Debut), selDayNum));	
//			DTselectByDate (addDays (dateObject, selDayNum));	
		};

		
		// masquage dialogue duplication
		$$(dialogDupliDomId).hide();
		
		// activation/affichage bouton selon l'utilisateur
		var userProfil = ds.Intervenant.getSessionInfos().userProfil;
		if (userProfil <= 2) {  //administrateur
			//
		} else {
			$$(buttonPrintDomID).disable();
			$$(buttonFindDomID).disable();
		}
		

	};

	function DTlistDupliSelected () {
//		debugger;

		var DT = $comp.sources.detail_Temps;
		var DTselection = DT.getSelection(); // get the current selection
		var DTselectedCount = DTselection.countSelected();
		var DTselectedRows = DTselection.getSelectedRows();
		var msg = '';
		
		if (DTselectedCount > 0) {
			if (DTselectedCount == 1) {
				msg = "Voulez-vous duplliquer l'enregistrement sélectionné ?";
			} else {
				msg = "Voulez-vous dupliquer les " + DTselectedCount + " enregistrements sélectionnés ?";				
			};
			
			$comp.sourcesVar.dupliMsgVar = msg;
			$comp.sources.dupliMsgVar.sync();

			$comp.sourcesVar.dupliDecalVar = 0;
			$comp.sources.dupliDecalVar.sync();

			$$(dialogDupliDomId).show();

		}		
	};
		
	function DTlistDeleteSelected () {
		//debugger;

		var DT = $comp.sources.detail_Temps;
		var DTselection = DT.getSelection(); // get the current selection
		var DTselectedCount = DTselection.countSelected();
		var DTselectedRows = DTselection.getSelectedRows();
		var msg = '';
		
		if (DTselectedCount > 0) {
			if (DTselectedCount == 1) {
				msg = "Voulez-vous supprimer l'enregistrement sélectionné ?";
			} else {
				msg = "Voulez-vous supprimer les " + DTselectedCount + " enregistrements sélectionnés ?";				
			};
			if(confirm(msg)) {
	    		var err = DT.deleteSelected(DTselectedRows);
					if (err !== 0)
					{
						alert("La suppression a échouée !" + "(erreur : " + String(err) + ")");
					} else {
						DTlistLoad(); //#TODO : à revoir	
					}
			}
		}		
	};
	
	function DTdetailLoad () {
		if ($comp.sources.detail_Temps.isNewElement()) {
			//new detail_Temps entity
			//date par defaut
			var selDayNum = $comp.sources.comboDayArr.getKey();
			if (selDayNum == 0) {  //tous les jours de la semaine
				//sélection détail temps de la semaine sélectionnée
				var dtDate = new Date($comp.sources.comboWeeksArr.SE_Date_Debut);	
			} else if ((selDayNum >= 1) && (selDayNum <=7)) {
				selDayNum--;
				//sélection détail temps du jour sélectionné de la semaine sélectionnée
				var dtDate = new Date(addDays (new Date($comp.sources.comboWeeksArr.SE_Date_Debut), selDayNum));	
			};	

			$comp.sources.detail_Temps.DET_Date = dtDate;			
		};
		
		//update var date
		$comp.sourcesVar.dtDateInputVar = new Date($comp.sources.detail_Temps.DET_Date);	
		$comp.sources.dtDateInputVar.sync();	//mise à jour interface
		$$(textFieldDateInputRef).focus();

		//positionnement combobox DPI
		comboDPIload($comp.sources.detail_Temps.DPI_ID);
		
		//mise à jour variable saisie Temps
		$comp.sourcesVar.dtTempsInputVar = timeFloat2Str ($comp.sources.detail_Temps.DET_Temps);
		$comp.sources.dtTempsInputVar.sync();
		
		resetPrevNextButtons();
	};

	function DTdetailValide () {
		var response = {},
		dt = $comp.sources.detail_Temps;
		
		//debugger;
		
		response.valid = true;
		if ((dt.DPI_ID == undefined) || (dt.DET_DPI == 0))
		{
			response.valid = false;
			response.msg = "Veuillez saisir un Dossier/Poste";
				
		} else if (dt.DET_Date == undefined)
		{
			response.valid = false;
			response.msg = "Veuillez saisir une date";
				
		} else if ($comp.sourcesVar.dtTempsInputVar == "0h")
		{
			response.valid = false;
			response.msg = "Veuillez saisir le temps";
		}
		
		return response;

	};
		
	function DTdetailSave () {
		
		//debugger;
		
		var dtValid = DTdetailValide();
		if (dtValid.valid) {			
			var dt = $comp.sources.detail_Temps;

			//#TODO :calcul pour les prix à reporter coté serveur
			//dt.DET_PrixVente = dt.Lien_DPI_DT.Lien_DOSPOS_DPI.Lien_POS_DOSPOS.POS_PrixJour;
			//dt.DET_TotalVenteHT = (dt.DET_PrixVente/8)*dt.DET_Temps;
			
			//update Temps 
			dt.DET_Temps = timeStr2float($comp.sourcesVar.dtTempsInputVar);

			if (dt.isNewElement()) {
				dt.save( {
					onSuccess : function(event) { 
						//Did we create the entity with our addNewEntity or custom server method.
						if (dt.getPosition() == -1) {
							//debugger;
							dt.addEntity(dt.getCurrentElement()); 
							var myColl = dt.getEntityCollection();
							
							DTlistLoad ();
							
//							myColl.refresh({ //access to the collection values on the server
//							    onSuccess: function(event){ 
//							    }
//							});
							
							
						} else {
							//DTlistLoad ();
						}
		        	},
		        	onError : function(err) {
						alert("L'enregistrement a échoué !" + " (erreur : " + String(err) + ")");        		
		        	}
		        });
			} else {
				dt.save( {
		        	onError : function(err) {
						alert("L'enregistrement a échoué !" + " (erreur : " + String(err) + ")");        		
		        	}
		        });		
			}

		} else {
			alert(dtValid.msg);	
		}

		return dtValid.valid;
	};
	
	function toogleListDetail (param) {
		if (param == 'list') {
			
			//sélection des détail temps de la semaine sélectionnée et/ou du jour de la semaine sélectionné
			DTlistLoad ();			

			$$(DTdetailContainer).hide();
			$$(DTlistContainer).show();
		} else {			
			DTdetailLoad ();

			$$(DTlistContainer).hide();
			$$(DTdetailContainer).show();		

		};		
	};


	//initialisations
	DTinit ();

	$$(DTlistContainer).show();
	toogleListDetail('list');
	
	// eventHandlers// @lock

	buttonCancel.click = function buttonCancel_click (event)// @startlock
	{// @endlock
		if ($comp.sources.detail_Temps.isNewElement()) {
			//l'élément vient d'être créé, il faut le supprimer
			$comp.sources.detail_Temps.removeCurrent( {
				onError : function(err) {
					alert("L'annulation a échouée !" + " (erreur : " + String(err) + ")");
				}
			})
		}
		toogleListDetail('list');
	};// @lock

	buttonSave.click = function buttonSave_click (event)// @startlock
	{// @endlock
		if (DTdetailSave ()) {
			toogleListDetail('list');// @lock
		}
	};
	
	buttonPrev.click = function buttonPrev_click (event)// @startlock
	{// @endlock
		if (DTdetailSave ()) {

		$comp.sources.detail_Temps.selectPrevious({
		    onSuccess:function(event) // asynchronous call (recommended)
		        {
					DTdetailLoad ();
		        }
			});
		}
	};// @lock

	buttonNext.click = function buttonNext_click (event)// @startlock
	{// @endlock
		if (DTdetailSave ()) {

			$comp.sources.detail_Temps.selectNext({
			    onSuccess:function(event) // asynchronous call (recommended)
			        {
						DTdetailLoad ();
			        }
				});
		}
	};// @lock

	textFieldInputTemps.blur = function textFieldInputTemps_blur (event)// @startlock
	{// @endlock
		//debugger;
		var timeStr = $comp.sourcesVar.dtTempsInputVar,
			timeFloat = timeStr2float (timeStr),
			timeStrVerif = timeFloat2Str(timeFloat);
		if (timeStr !== timeStrVerif) {
			$comp.sourcesVar.dtTempsInputVar = timeStrVerif;
			$comp.sources.dtTempsInputVar.sync();
		}	 
	};// @lock

	comboboxDPI.change = function comboboxDPI_change (event)// @startlock
	{// @endlock
		$comp.sources.detail_Temps.DPI_ID = $comp.sources.dosPosInt_A.DPI_ID;
	};// @lock

	buttonDelete.click = function buttonDelete_click (event)// @startlock
	{// @endlock
		DTlistDeleteSelected ();
	};// @lock

	DTdataGrid2.onRowDblClick = function DTdataGrid2_onRowDblClick (event)// @startlock
	{// @endlock
		toogleListDetail('detail');
	};// @lock

	buttonAdd.click = function buttonAdd_click (event)// @startlock
	{// @endlock
		//debugger;
		//#TODO : à améliorer
		$comp.sources.detail_Temps.newEntity();
		$comp.sources.detail_Temps.serverRefresh({
			onSuccess: function(event) {
				toogleListDetail('detail');
			}
		});
		//$comp.sources.detail_Temps.addNewElement();
	
	};// @lock

	comboboxDay.change = function comboboxDay_change (event)// @startlock
	{// @endlock
		var selDayNum = $comp.sources.comboDayArr.getKey();
		if (selDayNum == 0) {  //tous les jours de la semaine
			//sélection détail temps de la semaine sélectionnée
			DTselectByDate ($comp.sources.comboWeeksArr.SE_Date_Fin,  $comp.sources.comboWeeksArr.SE_Date_Debut);	
		} else if ((selDayNum >= 1) && (selDayNum <=7)) {
			selDayNum--; //0-6
			//sélection détail temps du jour sélectionné de la semaine sélectionnée
			DTselectByDate (addDays (new Date($comp.sources.comboWeeksArr.SE_Date_Debut), selDayNum));	
//			DTselectByDate (addDays (dateObject, selDayNum));	
		};

	};// @lock

	buttonDupli.click = function buttonDupli_click (event)// @startlock
	{// @endlock
		DTlistDupliSelected ();
	};// @lock

	buttonDupliCancel.click = function buttonDupliCancel_click (event)// @startlock
	{// @endlock
		$$(dialogDupliDomId).hide();
	};// @lock

	buttonDupliOK.click = function buttonDupliOK_click (event)// @startlock
	{// @endlock
		//debugger;
		var dt = $comp.sources.detail_Temps,
			dtSelectedRows = dt.getSelection().getSelectedRows();
			err = dt.dupliSelected(dtSelectedRows, $comp.sourcesVar.dupliDecalVar);
			if (err !== 0) {
				alert("La duplication a échouée !" + "(erreur : " + String(err) + ")");
			} else {
				DTlistLoad();
			}
		$$(dialogDupliDomId).hide();
	};// @lock

	dtDateInputVarEvent.onAttributeChange = function dtDateInputVarEvent_onAttributeChange (event)// @startlock
	{// @endlock
		$comp.sources.detail_Temps.DET_Date = $comp.sourcesVar.dtDateInputVar;
	};// @lock

	comboWeeksArrEvent.onSE_IDAttributeChange = function comboWeeksArrEvent_onSE_IDAttributeChange (event)// @startlock
	{// @endlock
		//sélection détail temps de la semaine sélectionnée
		DTselectByDate ($comp.sources.comboWeeksArr.SE_Date_Fin,  $comp.sources.comboWeeksArr.SE_Date_Debut);
		$comp.sources.comboDayArr.select(0); //tous les jours de la semaine		
	
	};// @lock

	dtDate_varEvent.onAttributeChange = function dtDate_varEvent_onAttributeChange (event)// @startlock
	{// @endlock
		//chargement comboBox semaines centrées sur la date choisie
		comboWeeksFill($comp.sourcesVar.dtDate_var, 21);
		
		$comp.sources.comboDayArr.select(0); //tous les jours de la semaine		

		//sélection détail temps de la semaine sélectionnée
		DTselectByDate ($comp.sources.comboWeeksArr.SE_Date_Fin,  $comp.sources.comboWeeksArr.SE_Date_Debut);	
	};// @lock

	detail_TempsEvent.onCollectionChange = function detail_TempsEvent_onCollectionChange (event)// @startlock
	{// @endlock
		 	refreshTotalHeures();
	};// @lock

	// @region eventManager// @startlock
	WAF.addListener(this.id + "_buttonCancel", "click", buttonCancel.click, "WAF");
	WAF.addListener(this.id + "_buttonSave", "click", buttonSave.click, "WAF");
	WAF.addListener(this.id + "_buttonPrev", "click", buttonPrev.click, "WAF");
	WAF.addListener(this.id + "_buttonNext", "click", buttonNext.click, "WAF");
	WAF.addListener(this.id + "_textFieldInputTemps", "blur", textFieldInputTemps.blur, "WAF");
	WAF.addListener(this.id + "_comboboxDPI", "change", comboboxDPI.change, "WAF");
	WAF.addListener(this.id + "_buttonDelete", "click", buttonDelete.click, "WAF");
	WAF.addListener(this.id + "_DTdataGrid2", "onRowDblClick", DTdataGrid2.onRowDblClick, "WAF");
	WAF.addListener(this.id + "_buttonAdd", "click", buttonAdd.click, "WAF");
	WAF.addListener(this.id + "_comboboxDay", "change", comboboxDay.change, "WAF");
	WAF.addListener(this.id + "_buttonDupli", "click", buttonDupli.click, "WAF");
	WAF.addListener(this.id + "_buttonDupliCancel", "click", buttonDupliCancel.click, "WAF");
	WAF.addListener(this.id + "_buttonDupliOK", "click", buttonDupliOK.click, "WAF");
	WAF.addListener(this.id + "_dtDateInputVar", "onAttributeChange", dtDateInputVarEvent.onAttributeChange, "WAF");
	WAF.addListener(this.id + "_comboWeeksArr", "onSE_IDAttributeChange", comboWeeksArrEvent.onSE_IDAttributeChange, "WAF", "SE_ID");
	WAF.addListener(this.id + "_dtDate_var", "onAttributeChange", dtDate_varEvent.onAttributeChange, "WAF");
	WAF.addListener(this.id + "_detail_Temps", "onCollectionChange", detail_TempsEvent.onCollectionChange, "WAF");
	// @endregion// @endlock

	};// @lock


}// @startlock
return constructor;
})();// @endlock
